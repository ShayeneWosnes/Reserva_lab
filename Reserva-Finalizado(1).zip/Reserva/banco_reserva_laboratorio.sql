create Database reserva_laboratorios;
use reserva_laboratorios; 


DROP TABLE IF EXISTS `laboratorio`;
CREATE TABLE `laboratorio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `numero_computadores` int NOT NULL,
  `bloco` varchar(50) NOT NULL,
  `sala` int NOT NULL,
  `liberado` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome` (`nome`)
) ;


INSERT INTO `laboratorio` VALUES (1,'D1',20,'D',01,1),(2,'D2',25,'D',02,1),(3,'D3',30,'D',03,1);


DROP TABLE IF EXISTS `pessoa`;

CREATE TABLE `pessoa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('A','U') NOT NULL,
  `ultimo_login` timestamp NULL DEFAULT NULL,
  `codigo_verificacao` int DEFAULT NULL,
  `confirmado` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ;


CREATE TABLE `reserva` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pessoa_id` int NOT NULL,
  `laboratorio_id` int NOT NULL,
  `data` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fim` time NOT NULL,
  `descricao` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pessoa_id` (`pessoa_id`),
  KEY `laboratorio_id` (`laboratorio_id`),
  CONSTRAINT `reserva_ibfk_1` FOREIGN KEY (`pessoa_id`) REFERENCES `pessoa` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reserva_ibfk_2` FOREIGN KEY (`laboratorio_id`) REFERENCES `laboratorio` (`id`) ON DELETE CASCADE
) ;

