<?php
$protegido = false;
require_once('../../config/database.php'); 
require_once('../../includes/session.inc.php');  
require_once('../../../vendor/autoload.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}


$usuario = unserialize(base64_decode($_SESSION['usuario']));
$username = $usuario['nome'] ?? '';
$userId = $usuario['id'] ?? '';
$userEmail = $usuario['email'] ?? '';


$isAdmin = false;
$sql = "SELECT tipo FROM Pessoa WHERE id = :id";
$stmt = $bancoDados->prepare($sql);
$stmt->bindParam(':id', $userId);
$stmt->execute();
if ($stmt->rowCount() == 1) {
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $isAdmin = ($user['tipo'] === 'A');
}


$exemploLaboratorios = [
    ['nome' => 'D1', 'numero_computadores' => 20, 'bloco' => 'D', 'sala' => 3, 'liberado' => 1],
    ['nome' => 'D2', 'numero_computadores' => 25, 'bloco' => 'D', 'sala' => 2, 'liberado' => 1],
    ['nome' => 'D3', 'numero_computadores' => 30, 'bloco' => 'D', 'sala' => 1, 'liberado' => 1],
    
];



foreach ($exemploLaboratorios as $laboratorio) {
    $query = $bancoDados->prepare("SELECT id FROM Laboratorio WHERE nome = :nome");
    $query->bindParam(':nome', $laboratorio['nome']);
    $query->execute();
    if ($query->rowCount() == 0) {
        $query = $bancoDados->prepare("INSERT INTO Laboratorio (nome, numero_computadores, bloco, sala, liberado) VALUES (:nome, :numero_computadores, :bloco, :sala, :liberado)");
        $query->bindParam(':nome', $laboratorio['nome']);
        $query->bindParam(':numero_computadores', $laboratorio['numero_computadores']);
        $query->bindParam(':bloco', $laboratorio['bloco']);
        $query->bindParam(':sala', $laboratorio['sala']);
        $query->bindParam(':liberado', $laboratorio['liberado']);
        $query->execute();
    }
}

$usuarios = array();
if ($isAdmin) {
    $query = $bancoDados->prepare("SELECT id, nome FROM Pessoa ORDER BY nome");
    if ($query->execute()) {
        if ($query->rowCount() > 0) {
            $usuarios = $query->fetchAll(PDO::FETCH_OBJ);
        }
    }
}


$reservaErro = null;
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reservar'])) {
    $laboratorio_id = $_POST['laboratorio_id'];
    $data = $_POST['data'];
    $hora_inicio = $_POST['hora_inicio'];
    $hora_fim = $_POST['hora_fim'];
    $descricao = $_POST['descricao'];
    $pessoa_id = $isAdmin && isset($_POST['pessoa_id']) ? $_POST['pessoa_id'] : $userId;

  
    $query = $bancoDados->prepare("SELECT id FROM Reserva WHERE laboratorio_id = :laboratorio_id AND data = :data AND hora_inicio = :hora_inicio AND hora_fim = :hora_fim");
    $query->bindParam(':laboratorio_id', $laboratorio_id);
    $query->bindParam(':data', $data);
    $query->bindParam(':hora_inicio', $hora_inicio);
    $query->bindParam(':hora_fim', $hora_fim);
    $query->execute();
    if ($query->rowCount() > 0) {
        $reservaErro = "Já existe uma reserva para esse laboratório, data e horário.";
    } else {
        $query = $bancoDados->prepare("INSERT INTO Reserva (pessoa_id, laboratorio_id, data, hora_inicio, hora_fim, descricao) VALUES (:pessoa_id, :laboratorio_id, :data, :hora_inicio, :hora_fim, :descricao)");
        $query->bindParam(':pessoa_id', $pessoa_id);
        $query->bindParam(':laboratorio_id', $laboratorio_id);
        $query->bindParam(':data', $data);
        $query->bindParam(':hora_inicio', $hora_inicio);
        $query->bindParam(':hora_fim', $hora_fim);
        $query->bindParam(':descricao', $descricao);

        if ($query->execute()) {
            
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'shayenevieirawosnes@gmail.com';
                $mail->Password = 'smjufsmoasxhpelve';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                $mail->setFrom('shayenevieirawosnes@gmail.com', 'Nao-responda');
                $mail->addAddress($userEmail, $username);

                $mail->isHTML(true);
                $mail->Subject = 'Nao-responda';
                $mail->Body = "<h1>Confirmação de Reserva</h1>
                               <p>Olá, {$username}. Reserva realizada com sucesso!.</p>
                               <p><strong>Laboratório:</strong> {$laboratorio_id}</p>
                               <p><strong>Data:</strong> {$data}</p>
                               <p><strong>Hora de Início:</strong> {$hora_inicio}</p>
                               <p><strong>Hora de Fim:</strong> {$hora_fim}</p>
                               <p><strong>Descrição:</strong> {$descricao}</p>";

                $mail->send();
            } catch (Exception $e) {
                echo "Erro ao enviar e-mail: {$mail->ErrorInfo}";
            }

            header("Location: home.php");
            exit;
        } else {
            $reservaErro = "Não foi possivel realizar a reserva. Tente novamente.";
        }
    }
}


$laboratorios = array();
$query = $bancoDados->prepare("SELECT id, nome FROM Laboratorio WHERE liberado = 1 ORDER BY nome");
if ($query->execute()) {
    if ($query->rowCount() > 0) {
        $laboratorios = $query->fetchAll(PDO::FETCH_OBJ);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 

</head>
<body>

<style> 
    .container{ 
            max-width: 1200px;
            margin-top: 10px;
            margin-bottom: 10px;
            padding: 10px;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
            background-color: #faf7f7;
            box-shadow: rgba(30, 30, 30, 0.8) 0px 7px 29px 0px;
            }

        .nav-item{
           background-color:#faf7f7;
           margin-bottom: 10px;
           text-align: center;
            max-width: 1200px
            padding: 5px;
            margin-left: 50px;
            margin-right: 60px;
            box-shadow: rgba(50, 50, 50, 0.5) 0px 7px 29px 0px;
            border-radius: 50%; width: 220px; height: 50px
        }
</style> 
    
    <div class="container">
        
    
        <h4 class="my-4"><center> Úsuario: <?php echo htmlspecialchars($username); ?></center></h4>
        
    <div class="fundo">
   
    
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="collapse navbar-collapse" id="navbarNav">
            
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="listar_reservas.php">Reservas</a>
                    </li>
                    <?php if ($isAdmin): 
                        echo' <li class="nav-item">
                            <a class="nav-link" href="cadastro_laboratorio.php">Cadastrado de Laboratório</a>
                        </li>';?>
                    <?php endif; ?>
                    <li class="nav-item">
                        
                        <a class="nav-link" href="sair.php">Sair</a>
                        
                    </div>
                        
                    </li>
                </ul>
                
            </div>
        </nav>
        
        <div class="mt-4">
            <h2><center>Reservas</center></h2>
            <form method="post" action="home.php">
            <div class="form-group">
                    <label for="laboratorio_id">Laboratório</label>
                    <select class="form-control" id="laboratorio_id" name="laboratorio_id" required>
                        <option value="">Selecione</option>
                        <?php foreach ($laboratorios as $laboratorio): ?>
                            <option value="<?= $laboratorio->id ?>"><?= htmlspecialchars($laboratorio->nome) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if ($isAdmin): ?>
                    <div class="form-group">
                        <label for="pessoa_id">Usuário</label>
                        <select class="form-control" id="pessoa_id" name="pessoa_id" required>
                            <option value="">Selecione</option>
                            <?php foreach ($usuarios as $usuario): ?>
                                <option value="<?= $usuario->id ?>"><?= htmlspecialchars($usuario->nome) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
               
                <div class="form-group">
                    <label for="data">Data</label>
                    <input type="date" class="form-control" id="data" name="data" required>
                </div>
                <div class="form-group">
                    <label for="hora_inicio">Hora de Início</label>
                    <input type="time" class="form-control" id="hora_inicio" name="hora_inicio" required>
                </div>
                <div class="form-group">
                    <label for="hora_fim">Hora de Fim</label>
                    <input type="time" class="form-control" id="hora_fim" name="hora_fim" required>
                </div>
                <div class="form-group">
                    <label for="descricao">OBSERVAÇÃO</label>
                    <textarea class="form-control" id="descricao" name="descricao" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary" name="reservar">Concluido</button>
                <?php if ($reservaErro): ?>
                    <div class="alert alert-danger mt-3">
                        <?= htmlspecialchars($reservaErro) ?>
                    </div>
                <?php endif; ?>
            </form>
        </div>

        <div class="mt-4">
            <h2><center> Histórico de Reservas</center></h2>
            <?php
            // Exibe as reservas
            $sql = "SELECT r.id, r.data, r.hora_inicio, r.hora_fim, r.descricao, l.nome AS laboratorio 
                    FROM Reserva r 
                    JOIN Laboratorio l ON r.laboratorio_id = l.id 
                    WHERE r.pessoa_id = :pessoa_id 
                    ORDER BY r.data DESC, r.hora_inicio DESC 
                    LIMIT 5";
            $stmt = $bancoDados->prepare($sql);
            $stmt->bindParam(':pessoa_id', $userId);
            $stmt->execute();
            $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
            ?>
            <?php if (!empty($reservas)): ?>
                <ul class="list-group">
                    <?php foreach ($reservas as $reserva): ?>
                        <li class="list-group-item">
                            <strong>Laboratório:</strong> <?php echo htmlspecialchars($reserva['laboratorio']); ?><br>
                            <strong>Data:</strong> <?php echo htmlspecialchars($reserva['data']); ?><br>
                            <strong>Início:</strong> <?php echo htmlspecialchars($reserva['hora_inicio']); ?><br>
                            <strong>Fim:</strong> <?php echo htmlspecialchars($reserva['hora_fim']); ?><br>
                            <strong>OBSERVAÇÃO:</strong> <?php echo htmlspecialchars($reserva['descricao']); ?><br>
                            <form method="post" action="excluir_reserva.php" class="mt-2">
                                <input type="hidden" name="reserva_id" value="<?= $reserva['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>Não há reservas recentes.</p>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
