<?php
require_once('../../config/database.php');
require_once('../../includes/session.inc.php');

// usuario logado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

// Recuperar dados do usuario
$usuario = unserialize(base64_decode($_SESSION['usuario']));
$userId = $usuario['id'];

// Verifica se o ID da reserva foi fornecido
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reserva_id'])) {
    $reserva_id = $_POST['reserva_id'];

    // Verifica se a reserva pertence ao usuario logado
    $query = $bancoDados->prepare("DELETE FROM Reserva WHERE id = :id AND pessoa_id = :pessoa_id");
    $query->bindParam(':id', $reserva_id);
    $query->bindParam(':pessoa_id', $userId);

    if ($query->execute()) {
        header("Location: home.php");
        exit;
    } else {
        echo "Erro. Tente novamente.";
    }
} else {
    header("Location: home.php");
    exit;
}
?>
